#!/usr/bin/env python3
"""Generate category pages (/category/<slug>/) from articles-index.json, news.json and manual-news.json.

Run after build-archive.py. Categories with fewer than MIN_INDEXABLE articles are noindex
and are left out of sitemap.xml.
"""
import json, html, re
from pathlib import Path
from seo_common import SITE, LOCAL_OG_URL, parse_date, safe_image

DEFS = {
    "politics": ("السياسة", "آخر الأخبار السياسية المغربية: الحكومة والبرلمان وقضية الصحراء والدبلوماسية.", {"policy"}),
    "morocco": ("أخبار المغرب", "آخر أخبار المغرب في الشؤون العامة والمجتمع.", {"general"}),
    "world": ("العالم", "أخبار العالم والتطورات الدولية.", {"international"}),
    "business": ("الاقتصاد", "أخبار الاقتصاد المغربي، الأسواق، الأعمال، والاستثمار.", {"business"}),
    "technology": ("التكنولوجيا", "آخر أخبار التكنولوجيا والذكاء الاصطناعي والابتكار.", {"technology"}),
    "sports": ("الرياضة", "أخبار الرياضة المغربية والمنتخبات والأندية.", {"sports"}),
}
MIN_INDEXABLE = 5
MAX_CARDS = 40


def esc(v):
    return html.escape(str(v or ""), quote=True)


def read_json(name, default):
    p = Path(name)
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else default


def load_articles():
    archive = read_json("articles-index.json", [])
    by_url = {a["url"]: a for a in archive}
    news = read_json("news.json", {})
    manual = read_json("manual-news.json", [])
    rows = (news.get("articles", []) if isinstance(news, dict) else news) + (manual if isinstance(manual, list) else [])
    out, seen = [], set()
    # articles from news.json / manual-news.json first (editorial order), then the permanent archive
    for a in rows:
        href = a.get("local_url") or a.get("url") or ""
        arch = by_url.get(href)
        if arch is not None and not arch["indexable"]:
            continue  # thin page, kept out of the index
        if not href or href in seen:
            continue
        seen.add(href)
        d = parse_date(a.get("date", ""))
        out.append({"href": href, "category": a.get("category", ""), "title": a.get("title", ""),
                    "description": a.get("description", ""), "image": safe_image(a.get("image")),
                    "date_iso": d.isoformat() if d else (arch or {}).get("date_iso", "")})
    for a in archive:
        if a["indexable"] and a["url"] not in seen:
            seen.add(a["url"])
            out.append({"href": a["url"], "category": a["category"], "title": a["title"],
                        "description": a["description"], "image": a["image"], "date_iso": a["date_iso"]})
    return out


def update_sitemap(active):
    p = Path("sitemap.xml")
    if not p.exists():
        return
    xml = p.read_text(encoding="utf-8")
    xml = re.sub(r"\s*<url>\s*<loc>" + re.escape(SITE) + r"/category/[a-z]+/?</loc>[\s\S]*?</url>", "", xml)
    entries = "\n".join(f"  <url><loc>{SITE}/category/{s}/</loc><lastmod>{d}</lastmod></url>" for s, d in active)
    p.write_text(xml.replace("</urlset>", entries + "\n</urlset>"), encoding="utf-8")


def build_nav(active_slugs):
    links = "".join(f'<a href="/category/{s}/">{DEFS[s][0]}</a>' for s in DEFS if s in active_slugs)
    return f'<nav><a href="/">الرئيسية</a>{links}<a href="/articles/">المقالات</a></nav>'


STYLE = ('body{margin:0;background:#f5f7f9;color:#17212b;font-family:Arial,sans-serif;line-height:1.8}header{background:#17212b;color:white;text-align:center;padding:16px}'
         'header a{color:white;text-decoration:none}nav{display:flex;flex-wrap:wrap;justify-content:center;gap:10px;background:white;padding:12px}nav a{color:#087f5b;text-decoration:none}'
         'main{max-width:1100px;margin:22px auto;padding:0 14px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:16px}'
         '.card{background:white;border-radius:14px;overflow:hidden;box-shadow:0 2px 12px #0001}.card a{color:inherit;text-decoration:none}'
         '.card img{width:100%;height:190px;object-fit:cover}.body{padding:14px}.date{font-size:13px;color:#667}')


def build():
    articles = load_articles()
    selection = {slug: sorted((a for a in articles if a["category"] in cats), key=lambda a: a["date_iso"], reverse=True)[:MAX_CARDS]
                 for slug, (_, _, cats) in DEFS.items()}
    nav = build_nav({s for s, rows in selection.items() if len(rows) >= MIN_INDEXABLE})
    active = []
    for slug, (title, description, cats) in DEFS.items():
        selected = selection[slug]
        canonical = f"{SITE}/category/{slug}/"
        indexable = len(selected) >= MIN_INDEXABLE
        robots = "index,follow" if indexable else "noindex,follow"
        if indexable:
            active.append((slug, (selected[0]["date_iso"] or "")[:10]))
        crumbs = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
            {"@type": "ListItem", "position": 1, "name": "الرئيسية", "item": SITE + "/"},
            {"@type": "ListItem", "position": 2, "name": title, "item": canonical}]}
        cards = "\n".join(
            f'<article class="card"><a href="{esc(a["href"])}"><img src="{esc(a["image"])}" alt="{esc(a["title"])}" width="400" height="190" loading="lazy">'
            f'<div class="body"><h2>{esc(a["title"])}</h2><p>{esc(a["description"][:160])}</p>'
            f'<time class="date" datetime="{esc(a["date_iso"][:10])}">{esc(a["date_iso"][:10])}</time></div></a></article>' for a in selected)
        page = ('<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                f'<title>{esc(title)} | NewsMorocco</title><meta name="description" content="{esc(description)}"><meta name="robots" content="{robots}">'
                f'<link rel="canonical" href="{canonical}"><meta property="og:type" content="website"><meta property="og:url" content="{canonical}">'
                f'<meta property="og:title" content="{esc(title)} | NewsMorocco"><meta property="og:description" content="{esc(description)}">'
                f'<meta property="og:image" content="{LOCAL_OG_URL}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">'
                f'<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{esc(title)} | NewsMorocco">'
                f'<meta name="twitter:description" content="{esc(description)}"><meta name="twitter:image" content="{LOCAL_OG_URL}">'
                f'<script type="application/ld+json">{json.dumps(crumbs, ensure_ascii=False)}</script><style>{STYLE}</style></head>'
                f'<body><header><a href="/">NewsMorocco — نبض المغرب والعالم</a></header>{nav}'
                f'<main><h1>{esc(title)}</h1><p>{esc(description)}</p><div class="grid">{cards}</div></main></body></html>')
        p = Path("category") / slug / "index.html"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(page, encoding="utf-8")
        print(f"Built {p}: {len(selected)} cards; robots={robots}")
    update_sitemap(active)


if __name__ == "__main__":
    build()
