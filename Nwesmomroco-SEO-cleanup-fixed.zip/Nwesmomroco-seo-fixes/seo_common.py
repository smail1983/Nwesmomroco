"""Shared helpers for the NewsMorocco build scripts (images, dates)."""
import re
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

SITE = "https://www.nwesmomroco.com"
LOCAL_OG = "/news-morocco-og-1200x630.png"   # local 1200x630 PNG used as the safe default image
LOCAL_OG_URL = SITE + LOCAL_OG

AR_MONTHS = {
    "يناير": 1, "فبراير": 2, "مارس": 3, "أبريل": 4, "ابريل": 4, "ماي": 5, "مايو": 5,
    "يونيو": 6, "يوليوز": 7, "يوليو": 7, "غشت": 8, "أغسطس": 8, "شتنبر": 9, "سبتمبر": 9,
    "أكتوبر": 10, "اكتوبر": 10, "نونبر": 11, "نوفمبر": 11, "دجنبر": 12, "ديسمبر": 12,
}
EN_MONTHS = {m: i for i, m in enumerate(
    ["january", "february", "march", "april", "may", "june", "july", "august",
     "september", "october", "november", "december"], 1)}


def is_external(url):
    url = url or ""
    if not re.match(r"^(https?:)?//", url):
        return False
    return not re.match(r"^https?://(www\.)?nwesmomroco\.com(/|$)", url)


def safe_image(url):
    """Return a local image path. Third-party (hotlinked) images are never used."""
    url = (url or "").strip()
    if not url or is_external(url):
        return LOCAL_OG
    url = re.sub(r"^https?://(www\.)?nwesmomroco\.com", "", url)
    return url if url.startswith("/") else "/" + url


def social_image(url):
    """Absolute URL for og:image / twitter:image / JSON-LD. SVG is not supported by social platforms."""
    path = safe_image(url)
    if re.search(r"\.svg(?:[?#]|$)", path, re.I):
        path = LOCAL_OG
    return SITE + path


def _to_utc(dt):
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def parse_date(*candidates):
    """Return a UTC datetime from ISO, RFC 2822, Arabic ('7 نونبر 2026') or 'month-day-year' text."""
    for text in candidates:
        if not text:
            continue
        text = str(text).strip()
        try:
            return _to_utc(datetime.fromisoformat(text.replace("Z", "+00:00")))
        except ValueError:
            pass
        try:
            return _to_utc(parsedate_to_datetime(text))
        except (TypeError, ValueError, IndexError, OverflowError):
            pass
        m = re.search(r"(\d{1,2})\s+(" + "|".join(AR_MONTHS) + r")\s+(20\d\d)", text)
        if m:
            return datetime(int(m.group(3)), AR_MONTHS[m.group(2)], int(m.group(1)), tzinfo=timezone.utc)
        m = re.search(r"(" + "|".join(EN_MONTHS) + r")-(\d{1,2})-(20\d\d)", text.lower())
        if m:
            return datetime(int(m.group(3)), EN_MONTHS[m.group(1)], int(m.group(2)), tzinfo=timezone.utc)
    return None
