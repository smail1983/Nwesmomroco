#!/usr/bin/env python3
"""Build the permanent article archive and sitemap.xml.

Outputs
  articles-index.json            all article pages (data file, also used by build-category-pages.py)
  articles/index.html            archive page 1 (static HTML, crawlable)
  articles/page/N/index.html     archive pages 2..N
  sitemap.xml                    home, archive, static pages and every indexable article
                                 (category pages are appended by build-category-pages.py)

The article HTML files are the source of truth. To publish a new article just add an
article-*.html file (with a NewsArticle JSON-LD block) and run this script.
"""
import glob
import html
import json
import re
from pathlib import Path

from seo_common import SITE, parse_date, safe_image, social_image, LOCAL_OG_URL

PAGE_SIZE = 24
KNOWN = {"policy", "sports", "business", "technology", "general", "international"}
LABELS = {"policy": "سياسة", "sports": "رياضة", "business": "اقتصاد", "technology": "تكنولوجيا",
          "general": "أخبار المغرب", "international": "العالم"}
STATIC_PAGES = ["/about.html", "/contact.html", "/editorial-policy.html", "/privacy.html", "/disclaimer.html"]
NAV = ('<a href="/">الرئيسية</a><a href="/category/politics/">السياسة</a><a href="/category/morocco/">المغرب</a>'
       '<a href="/category/business/">الاقتصاد</a><a href="/category/sports/">الرياضة</a>'
       '<a href="/articles/">المقالات</a>')


def esc(v):
    return html.escape(str(v or ""), quote=True)


def clean(value):
    value = html.unescape(value or "")
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", value)).strip()


def category_from(text):
    text = text.lower()
    if "رياضة" in text or "sport" in text:
        return "sports"
    if "اقتصاد" in text or "business" in text:
        return "business"
    if "تكنولوجيا" in text or "تقنية" in text or "technology" in text:
        return "technology"
    if "سياسة" in text or "حكومة" in text or "صحراء" in text or "policy" in text:
        return "policy"
    return "general"


def article_files():
    files = set(glob.glob("article-*.html"))
    for p in glob.glob("*.html"):  # hand-made pages that are not named article-*.html
        if p not in files and "NewsArticle" in Path(p).read_text(encoding="utf-8", errors="ignore"):
            files.add(p)
    return sorted(files)


def read_article(path):
    raw = Path(path).read_text(encoding="utf-8", errors="ignore")
    m = re.search(r"<h1[^>]*>(.*?)</h1>", raw, re.I | re.S) or re.search(r"<title[^>]*>(.*?)</title>", raw, re.I | re.S)
    title = clean(m.group(1)) if m else Path(path).stem
    m = re.search(r'<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']', raw, re.I | re.S)
    description = html.unescape(m.group(1)).strip() if m else ""
    m = re.search(r"<img[^>]+src=[\"']([^\"']+)", raw, re.I | re.S)
    image = safe_image(html.unescape(m.group(1)) if m else "")
    m = re.search(r'<(?:div|p)[^>]+class=["\'][^"\']*meta[^"\']*["\'][^>]*>(.*?)</(?:div|p)>', raw, re.I | re.S)
    meta = clean(m.group(1)) if m else ""
    ld_date = re.search(r'"datePublished":\s*"([^"]+)"', raw)
    pub = re.search(r'article:published_time"\s+content="([^"]+)"', raw)
    date = parse_date(ld_date.group(1) if ld_date else "", pub.group(1) if pub else "", meta, path)
    section = re.search(r'"articleSection":\s*"([^"]+)"', raw)
    category = section.group(1) if section and section.group(1) in KNOWN else category_from(meta + " " + title)
    noindex = bool(re.search(r'<meta\s+name=["\']robots["\']\s+content=["\']noindex', raw, re.I))
    return {
        "category": category, "title": title, "description": description, "image": image,
        "url": "/" + Path(path).name, "domain": "NewsMorocco", "date": meta,
        "date_iso": date.isoformat() if date else "", "indexable": not noindex,
    }


def page_url(n):
    return f"{SITE}/articles/" if n == 1 else f"{SITE}/articles/page/{n}/"


def card(a):
    return (f'<article class="card"><a href="{esc(a["url"])}"><img src="{esc(a["image"])}" alt="{esc(a["title"])}" '
            f'width="400" height="190" loading="lazy"><div class="card-body"><span class="tag">{esc(LABELS.get(a["category"], "أخبار"))}</span>'
            f'<h2>{esc(a["title"])}</h2><p>{esc(a["description"][:160])}</p>'
            f'<time class="date" datetime="{esc(a["date_iso"][:10])}">{esc(a["date_iso"][:10])}</time></div></a></article>')


STYLE = ('*{box-sizing:border-box}body{margin:0;background:#f5f7f9;color:#17212b;font-family:Arial,"Noto Sans Arabic",sans-serif;line-height:1.8}'
         'header{background:#17212b;padding:14px 16px}.wrap{max-width:1100px;margin:auto}.logo{color:#fff;text-decoration:none;font-size:24px;font-weight:800}'
         '.logo span{color:#ef4b3f}nav{display:flex;flex-wrap:wrap;gap:6px 14px;margin-top:8px}nav a{color:#e5e7eb;text-decoration:none;font-size:15px}'
         '.main{padding:26px 16px}h1{margin:0 0 8px;font-size:30px}.intro{color:#667085;margin-bottom:22px}'
         '.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:18px}.card{background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 3px 14px rgba(0,0,0,.08)}'
         '.card a{color:inherit;text-decoration:none;display:block}.card img{width:100%;height:190px;object-fit:cover;background:#eee;display:block}'
         '.card-body{padding:14px}.card h2{font-size:18px;line-height:1.6;margin:6px 0}.card p{margin:0;color:#667085;font-size:14px}'
         '.tag{background:#d71920;color:#fff;border-radius:6px;padding:3px 9px;font-size:12px;font-weight:700}.date{color:#888;font-size:12px}'
         '.pager{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin:28px 0}.pager a,.pager span{padding:8px 14px;border-radius:8px;background:#fff;border:1px solid #ddd;color:#17212b;text-decoration:none}'
         '.pager .cur{background:#087f5b;color:#fff;border-color:#087f5b}')


def archive_page(items, n, pages, total):
    canonical = page_url(n)
    title = "أرشيف جميع المقالات" + (f" — الصفحة {n}" if n > 1 else "")
    desc = "أرشيف مقالات وأخبار NewsMorocco: السياسة والأخبار المغربية والرياضة والاقتصاد والتكنولوجيا."
    links = ""
    if n > 1:
        links += f'<link rel="prev" href="{page_url(n - 1)}">'
    if n < pages:
        links += f'<link rel="next" href="{page_url(n + 1)}">'
    pager = []
    for i in range(1, pages + 1):
        if i == n:
            pager.append(f'<span class="cur">{i}</span>')
        elif i <= 3 or i > pages - 2 or abs(i - n) <= 2:
            pager.append(f'<a href="{page_url(i).replace(SITE, "")}">{i}</a>')
        elif pager and pager[-1] != "<span>…</span>":
            pager.append("<span>…</span>")
    crumbs = {"@context": "https://schema.org", "@type": "CollectionPage", "name": title, "url": canonical,
              "isPartOf": {"@type": "WebSite", "name": "NewsMorocco", "url": SITE + "/"}}
    return (f'<!DOCTYPE html>\n<html lang="ar" dir="rtl">\n<head>\n<meta charset="UTF-8">\n'
            f'<meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
            f'<title>{esc(title)} | NewsMorocco</title>\n<meta name="description" content="{esc(desc)}">\n'
            f'<meta name="robots" content="index,follow">\n<link rel="canonical" href="{canonical}">\n{links}\n'
            f'<meta property="og:type" content="website"><meta property="og:site_name" content="NewsMorocco">'
            f'<meta property="og:title" content="{esc(title)}"><meta property="og:description" content="{esc(desc)}">'
            f'<meta property="og:url" content="{canonical}"><meta property="og:image" content="{LOCAL_OG_URL}">'
            f'<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">'
            f'<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{esc(title)}">'
            f'<meta name="twitter:description" content="{esc(desc)}"><meta name="twitter:image" content="{LOCAL_OG_URL}">\n'
            f'<script type="application/ld+json">{json.dumps(crumbs, ensure_ascii=False)}</script>\n<style>{STYLE}</style>\n</head>\n<body>\n'
            f'<header><div class="wrap"><a class="logo" href="/">News<span>Morocco</span></a><nav>{NAV}</nav></div></header>\n'
            f'<main class="wrap main"><h1>{esc(title)}</h1><p class="intro">{total} مقالاً منشوراً. الأخبار الجديدة تظهر في الرئيسية، '
            f'والمقالات السابقة تبقى محفوظة هنا.</p>\n<section class="grid">\n' + "\n".join(card(a) for a in items) +
            f'\n</section>\n<nav class="pager" aria-label="الصفحات">{"".join(pager)}</nav></main>\n</body>\n</html>\n')


def write_sitemap(indexable, newest):
    rows = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    rows.append(f"  <url><loc>{SITE}/</loc><lastmod>{newest}</lastmod></url>")
    rows.append(f"  <url><loc>{SITE}/articles/</loc><lastmod>{newest}</lastmod></url>")
    for p in STATIC_PAGES:
        if Path(p.lstrip("/")).exists():
            rows.append(f"  <url><loc>{SITE}{p}</loc></url>")
    for a in indexable:
        lastmod = f"<lastmod>{a['date_iso'][:10]}</lastmod>" if a["date_iso"] else ""
        rows.append(f"  <url><loc>{SITE}{a['url']}</loc>{lastmod}</url>")
    rows.append("</urlset>")
    Path("sitemap.xml").write_text("\n".join(rows) + "\n", encoding="utf-8")


def main():
    archive = [read_article(p) for p in article_files()]
    archive.sort(key=lambda a: (a["date_iso"], a["title"]), reverse=True)
    Path("articles-index.json").write_text(json.dumps(archive, ensure_ascii=False, indent=2), encoding="utf-8")

    listed = [a for a in archive if a["indexable"]]  # thin (noindex) pages are not listed in the archive
    pages = max(1, -(-len(listed) // PAGE_SIZE))
    for old in Path("articles/page").glob("*/index.html") if Path("articles/page").exists() else []:
        old.unlink()
    for n in range(1, pages + 1):
        chunk = listed[(n - 1) * PAGE_SIZE: n * PAGE_SIZE]
        out = Path("articles/index.html") if n == 1 else Path(f"articles/page/{n}/index.html")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(archive_page(chunk, n, pages, len(listed)), encoding="utf-8")
    newest = next((a["date_iso"][:10] for a in listed if a["date_iso"]), "")
    write_sitemap(listed, newest)
    print(f"Built archive: {len(archive)} article pages, {len(listed)} indexable, {pages} archive pages, sitemap refreshed.")


if __name__ == "__main__":
    main()
